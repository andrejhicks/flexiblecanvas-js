# Schedule reasoning and natural-language translation

## Contents

1. Scheduling model
2. Natural-language intent
3. Date-alignment audit
4. Duration changes
5. Dependency changes
6. Template-specific invariants
7. Validation and evidence

## 1. Scheduling model

For task `i`, reason with:

- start `S_i`;
- finish `F_i`;
- working duration `D_i`;
- schedule mode and effort/units;
- calendar `C_i`;
- explicit constraint/anchor `K_i`;
- assignments/progress `R_i`.

Conceptually, `F_i = work_add(S_i, D_i, C_i)`. Never substitute elapsed-day arithmetic when working calendars matter.

Dependency lower bounds with working-calendar lag `L`:

| Type | Required boundary |
| --- | --- |
| FS A → B | `S_B >= work_add(F_A, L)` |
| SS A → B | `S_B >= work_add(S_A, L)` |
| FF A → B | `F_B >= work_add(F_A, L)` |
| SF A → B | `F_B >= work_add(S_A, L)` |

A dependency establishes a lower bound, not always equality. Positive slack can be legitimate.

## 2. Natural-language intent

Translate language to intent before choosing fields or actions:

| User request | Typed intent | Preferred implementation |
| --- | --- | --- |
| “B starts after A finishes” | hard order A → B, FS | create/replace dependency |
| “B starts when A starts” | hard start alignment, SS | SS dependency after tenant support check |
| “B finishes with A” | hard finish alignment, FF | FF dependency after tenant support check |
| “B can overlap A” | overlap allowed | remove unnecessary hard edge only if approved |
| “Prefer A before B” | soft order | no edge unless user accepts a hard relationship |
| “Shorten B to five days” | duration = 5 working days | minimal task duration update; inspect schedule mode |
| “Shorten B by two days” | duration = current − 2 working days | calculate from current value; reject negative result |
| “Move B to Monday” | ambiguous date intent | ask whether this is constraint, dependency, lag, duration, or anchor change |
| “B cannot start before Monday” | SNET-style explicit constraint | use supported constraint/anchor field exposed by service |
| “Finish by T-30” | hard no-later-than finish target | timing intent/validation; do not invent a dependency |
| “Finish exactly T-30” | exact finish anchor | explicit anchor/constraint or verified dependency pattern |
| “Start at T-90” | exact start anchor | start-integration/constraint record |
| “Remove the date pin on B” | remove/reset explicit constraint | inspect actual constraint fields; reset to tenant-supported flexible/default state |
| “Re-sequence A, B, C” | ordered chain | minimal acyclic edges, preserve unrelated/locked edges |

Interpret “days” as working days by default only when the project calendar is known. Otherwise identify the missing basis before publishing.

## 3. Date-alignment audit

Compute each task's network-driven earliest boundary from all incoming dependencies and the project/module anchor. Compare it with the persisted scheduled date.

Classify findings:

1. **Dependency violation**: scheduled boundary is earlier than a required dependency boundary.
2. **Aligned**: scheduled boundary equals the strongest network/anchor lower bound within calendar tolerance.
3. **Explained positive gap**: scheduled date is later and an explicit constraint, anchor, resource calendar, progress/actual, manual lock, leveling rule, or nonworking interval explains it.
4. **Possible UI-driven constraint**: scheduled date is later, no known driver explains it, and the task was likely date-edited. This is a hypothesis.
5. **Unverifiable**: required calendar, lag, duration, assignment, progress, or constraint fields are missing.

Microsoft Project documentation warns that editing Start or Finish can place a constraint on a task. Project Operations uses the Project scheduling engine, but do not infer a specific constraint type from dates alone. Confirm using one or more of:

- constraint/anchor fields returned by the service;
- record/audit history showing a UI date edit;
- controlled simulation that removes or resets the constraint in a draft;
- comparison against an equivalent unconstrained task;
- visual inspection of task details.

When investigating a suspicious task, snapshot all incident dependency IDs and fields. A prior observed failure mode in this environment is that a start-date write can disturb dependencies.

## 4. Duration changes

Before changing duration:

1. Reject summary-task duration edits; summary dates/duration roll up from children.
2. Inspect milestone state; a milestone should have zero duration.
3. Inspect project/task schedule mode.
4. Inspect effort, units, assignments, calendars, progress, and actuals.
5. State which coupled value PSS should recalculate.
6. Simulate downstream dates and critical-path impact.
7. Update only the supported duration field exposed by the service; do not also force start/finish unless intent explicitly requires a constraint.

If a task has progress or actual dates, avoid rewriting historical portions of the schedule. Escalate to the service's rescheduling semantics.

## 5. Dependency changes

Resolve every endpoint by stable ID and verify:

- same project;
- same module for template scheduling;
- neither endpoint is a summary task;
- predecessor != successor;
- no duplicate edge;
- new edge does not create a cycle;
- relationship type/lag is supported by tenant metadata;
- locked relationships remain unchanged;
- operation stays under platform link limits.

Use graph reachability to avoid redundant generated edges. Preserve a redundant user-locked edge unless the user explicitly replaces it.

To change type, lag, or an endpoint, delete the old dependency row and create a new row in the same OperationSet. Generate the replacement ID before queuing if later operations reference it.

## 6. Template-specific invariants

Treat each summary task as a hard module boundary. Cross-module coordination occurs through rig-relative date anchors, not dependencies.

Evaluation order:

1. resolve Country and Project Type;
2. exclude inapplicable tasks and start-integration records;
3. ensure global tasks remain included;
4. resolve exactly one active record for each required anchor group;
5. reject an active record whose target task is excluded;
6. remove generated edges incident to excluded tasks;
7. merge preserved locked edges;
8. generate the minimal same-module acyclic graph;
9. calculate calendar-aware dates;
10. test exact/no-later-than rig-relative targets;
11. test every supported configuration before publish.

Never compile a T-minus target into FF+lag merely because it produces one desired date in one scenario. Timing intent remains separate from ordering intent.

## 7. Validation and evidence

Before approval, provide:

- snapshot version and timestamp;
- task/dependency IDs;
- graph validation results;
- current and proposed values;
- predicted cascade by task;
- assumptions and unknowns;
- operation count;
- a rollback or compensating plan when the service lacks true atomicity.

After execution, compare the same fields and rerun the audit. A successful HTTP/action response is not evidence that the final schedule matches intent.
