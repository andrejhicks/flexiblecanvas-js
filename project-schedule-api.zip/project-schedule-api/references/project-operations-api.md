# Project Operations Schedule API reference

Verified against Microsoft documentation on 2026-08-14. Treat tenant metadata and the connected tool schema as authoritative because Project Operations is updated monthly and navigation-property names can be case-sensitive.

## Contents

1. Scheduling authority and entities
2. Actions and transaction pattern
3. Supported mutation behavior
4. Task and dependency fields
5. Schedule modes
6. Limits, identity, and diagnostics
7. Official sources

## 1. Scheduling authority and entities

Use ordinary Dataverse/OData reads to inspect schedule records. Use PSS actions—not direct Dataverse create/update/delete—for schedule-impacting writes to these entities:

| Entity | Logical name |
| --- | --- |
| Project | `msdyn_project` |
| Project Task | `msdyn_projecttask` |
| Project Task Dependency | `msdyn_projecttaskdependency` |
| Resource Assignment | `msdyn_resourceassignment` |
| Project Bucket | `msdyn_projectbucket` |
| Project Team Member | `msdyn_projectteam` |
| Project Checklist | `msdyn_projectchecklist` |
| Project Label | `msdyn_projectlabel` |
| Project Task to Label | `msdyn_projecttasktolabel` |
| Project Sprint | `msdyn_projectsprint` |

Custom configuration entities that do not affect the PSS schedule may use standard Dataverse operations. Do not assume a custom field is harmless: inspect its plug-ins and integration behavior first.

## 2. Actions and transaction pattern

| Action | Purpose | Core parameters |
| --- | --- | --- |
| `msdyn_CreateOperationSetV1` | Open an atomic schedule unit | `ProjectId`, `Description` |
| `msdyn_PssCreateV1` | Queue one entity create | `Entity`, `OperationSetId` |
| `msdyn_PssCreateV2` | Queue multiple creates | `EntityCollection`, `OperationSetId` |
| `msdyn_PssUpdateV1` | Queue one entity update | `Entity`, `OperationSetId` |
| `msdyn_PssUpdateV2` | Queue multiple updates | `EntityCollection`, `OperationSetId` |
| `msdyn_PssDeleteV1` | Queue one entity delete | `RecordId`, `EntityLogicalName`, `OperationSetId` |
| `msdyn_PssDeleteV2` | Queue multiple deletes | Inspect the tenant action metadata/tool schema |
| `msdyn_ExecuteOperationSetV1` | Submit queued operations | `OperationSetId` |
| `msdyn_AbandonOperationSetV1` | Abandon an unneeded open set | `OperationSetId` |
| `msdyn_PssUpdateResourceAssignmentV1` / contour action exposed by tenant | Update planned-work contour | assignment ID, contours, OperationSet ID |
| `msdyn_CreateProjectV1` | Immediately create a project/default bucket | `Project` |
| `msdyn_CreateTeamMemberV1` | Immediately create a team member | `TeamMember` |

Some Microsoft samples and connectors display parameter labels differently. Inspect `$metadata`, the generated SDK request, or the connected tool definition before emitting raw HTTP. Do not invent V2 delete parameter names.

Canonical mutation sequence:

1. Read affected records and retain a version/revision guard.
2. Create OperationSet.
3. Queue minimal create/update/delete operations.
4. Execute OperationSet.
5. Track status/correlation ID and inspect errors.
6. Re-read and validate the schedule.

If queuing fails before execution, abandon the set. Do not abandon an executed set.

## 3. Supported mutation behavior

- Project tasks support create, update, and delete.
- Project Task Dependency rows support create and delete, not update. Replace a relationship with delete + create.
- Resource Assignment rows are effectively replaced for general changes; use the dedicated contour API for `msdyn_plannedwork`.
- Projects support create and update, not delete through PSS. Several calculated project fields are not supported for update, including Finish and Duration.
- Project/Team Member create actions execute immediately and do not participate directly in the OperationSet.
- V2 actions batch entities but every queued entity still contributes to the 200-operation limit.
- IDs can be client-provided. Generate IDs before the OperationSet when later operations must reference newly created entities.

Minimal V1 SDK semantics:

```text
CreateOperationSet(ProjectId, Description) -> OperationSetId
PssCreate(Entity, OperationSetId)
PssUpdate(Entity, OperationSetId)
PssDelete(RecordId, EntityLogicalName, OperationSetId)
ExecuteOperationSet(OperationSetId)
```

## 4. Task and dependency fields

Read at least the following task semantics. Confirm exact tenant field availability:

- identity/project: `msdyn_projecttaskid`, project lookup;
- name/hierarchy: `msdyn_subject`, parent-task lookup, `msdyn_outlinelevel`, display sequence;
- time: `msdyn_duration` (days), `msdyn_scheduleddurationminutes`, `msdyn_scheduledstart`, `msdyn_scheduledend`, plus any current Start/Finish fields exposed by the tenant;
- work/state: `msdyn_effort`, progress/actual fields, milestone and critical flags when available;
- scheduling: project schedule mode, `msdyn_taskschedulemode` when task-level schedule mode is enabled, calendar/assignment/constraint/anchor fields;
- governance: custom module ID, global-task flag, lock fields, and template version.

Dependency semantics:

- primary ID: `msdyn_projecttaskdependencyid`;
- project lookup: `msdyn_project`;
- predecessor lookup: `msdyn_predecessortask`;
- successor lookup: `msdyn_successortask`;
- link type: `msdyn_linktype` when present.

Documented `msdyn_linktype` values:

| Type | Value |
| --- | ---: |
| Finish-to-Start | 192350000 |
| Start-to-Start | 192350001 |
| Finish-to-Finish | 192350002 |
| Start-to-Finish | 192350004 |

Some tenants also expose `msdyn_projecttaskdependencylinktype`; inspect metadata and preserve the tenant's established representation. Lag/lead support and its field representation must be discovered from tenant metadata or the service contract. Never fabricate a lag column.

Entity update payloads must contain `@odata.type`, the record ID, and only changed fields. Entity create payloads must include the required lookups. For dependency creates, use exact navigation-property names from tenant metadata; `@odata.bind` property names are case-sensitive.

## 5. Schedule modes

At the project level, fixed duration, fixed effort, and fixed units determine which part of `Effort = Duration × Units` is held constant. Inspect schedule mode before modifying duration, effort, or assignments and explain the coupled value that PSS is expected to recalculate.

Task-level schedule modes are a 2026 preview and use `msdyn_taskschedulemode`:

| Mode | Value |
| --- | ---: |
| Fixed Effort | 192350000 |
| Fixed Duration | 192350001 |
| Fixed Units | 192350002 |
| Fixed Duration Effort Driven | 192350003 |
| Fixed Units Effort Driven | 192350004 |

Do not send `null` or an invalid value. Summary tasks are always fixed duration.

## 6. Limits, identity, and diagnostics

Current Microsoft limits include:

- 200 operations per OperationSet;
- 10 open OperationSets per user;
- licensed Microsoft Project user required; application, system, and integration users cannot call the schedule APIs;
- 3,000 tasks and 2,000 successor links per project;
- 20 combined predecessor/successor links per task;
- hierarchy depth 10;
- leaf-task duration up to 1,250 days;
- project/summary duration up to 5,475 days;
- 50 assigned resources per task;
- task dates between 2000-01-01 and 2149-12-31.

Duration limits assume an eight-hour workday and adjust with project Hours per Day.

For diagnostics, inspect:

- Settings > Schedule Integration > Operation Sets;
- Operation Set Details for serialized Dataverse/PSS payload and request order;
- PSS Error Logs for error code, log, call stack, project, session, and correlation ID.

Logs are cleaned up on a configured retention interval, so persist relevant correlation IDs and per-record results in the agent's audit record.

## 7. Official sources

- Schedule API actions, supported operations, limits, and SDK samples: https://learn.microsoft.com/en-us/dynamics365/project-operations/project-management/schedule-api-preview
- V2 Power Automate example: https://learn.microsoft.com/en-us/dynamics365/project-operations/project-management/scheduling-apis-powerautomate-v2
- OperationSet and PSS logs: https://learn.microsoft.com/en-us/dynamics365/project-operations/project-management/schedule-api-logs
- Project/task limits: https://learn.microsoft.com/en-us/dynamics365/project-operations/project-management/project-and-task-limitations
- Scheduling modes: https://learn.microsoft.com/en-us/dynamics365/project-operations/project-management/scheduling-modes
- Task-level schedule modes preview: https://learn.microsoft.com/en-us/dynamics365/project-operations/project-management/task-level-schedule-modes
- Project Task CDM fields: https://learn.microsoft.com/en-us/common-data-model/schema/core/applicationcommon/foundationcommon/crmcommon/projectcommon/projectserviceautomation/projecttask
- Dependency CDM fields/link values: https://learn.microsoft.com/en-us/common-data-model/schema/core/applicationcommon/foundationcommon/crmcommon/projectcommon/projectserviceautomation/projecttaskdependency
- Date-entry constraint behavior: https://support.microsoft.com/en-us/project/set-a-task-start-or-finish-date-constraint-for-a-task
