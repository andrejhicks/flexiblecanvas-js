# Service and tool contract

Use this reference to bind schedule reasoning to the tools actually available. Tool names are illustrative; map by behavior and inspect the schema before calling.

## Contents

1. Required capabilities
2. Normalized change plan
3. Tool-call sequence
4. PSS entity compilation
5. Failure handling

## 1. Required capabilities

A production schedule service should expose equivalent capabilities:

| Capability | Side effect | Required output |
| --- | --- | --- |
| Read coherent project schedule | none | project/version, tasks, hierarchy, dependencies, modes, calendars, assignments, constraints/anchors, locks |
| Resolve task identity | none | stable task ID plus disambiguating module/WBS |
| Simulate change set | none | predicted tasks/dependencies, violations, operation count |
| Produce final diff | none | current/proposed values and a diff hash |
| Apply approved change set | live write | expected version, approval/diff hash, OperationSet/correlation ID, per-record results |
| Read operation status/logs | none | terminal status or error detail |
| Re-read affected schedule | none | post-write values/version |
| Abandon open set | write/cleanup | confirmed abandoned status |

If the service only exposes raw Dataverse actions, build these safeguards in the calling code. If it cannot provide a version guard or post-write read, do not perform unattended writes.

## 2. Normalized change plan

Translate a request into a plan before tool calls:

```json
{
  "project_id": "guid",
  "base_version": "opaque-version",
  "scope": {"module_ids": [], "task_ids": []},
  "intent": "human-readable intent",
  "operations": [
    {
      "op": "update_task",
      "task_id": "guid",
      "changes": {"duration_days": 5},
      "preserve": ["start", "finish", "dependencies"]
    },
    {
      "op": "replace_dependency",
      "dependency_id": "guid",
      "predecessor_task_id": "guid",
      "successor_task_id": "guid",
      "type": "FS",
      "lag_minutes": 0
    }
  ],
  "assumptions": [],
  "expected_effect": {},
  "validation_ids": []
}
```

Use the service's exact schema. Do not pass invented fields such as `lag_minutes` when the service represents lag differently.

## 3. Tool-call sequence

### Inspection or diagnosis

1. Read schedule snapshot.
2. Run deterministic audit/simulation.
3. Read logs/audit history only when needed to explain anomalies.
4. Return evidence-based findings; do not write.

### Proposed modification

1. Read snapshot and resolve IDs.
2. Build normalized plan.
3. Validate and simulate.
4. Generate final diff/diff hash.
5. Ask for explicit approval of that diff.

### Approved modification

1. Re-read version and affected records.
2. Reject changed version/diff.
3. Invoke one guarded apply operation, or explicitly create/queue/execute an OperationSet.
4. Track status and per-record results.
5. Re-read tasks and incident dependencies.
6. Revalidate dates and graph.

Never reuse approval after the diff changes.

## 4. PSS entity compilation

Conceptual minimal task update:

```json
{
  "@odata.type": "Microsoft.Dynamics.CRM.msdyn_projecttask",
  "msdyn_projecttaskid": "TASK_GUID",
  "msdyn_duration": 5
}
```

Conceptual dependency create:

```json
{
  "@odata.type": "Microsoft.Dynamics.CRM.msdyn_projecttaskdependency",
  "msdyn_projecttaskdependencyid": "NEW_DEPENDENCY_GUID",
  "PROJECT_NAVIGATION_PROPERTY@odata.bind": "/msdyn_projects(PROJECT_GUID)",
  "PREDECESSOR_NAVIGATION_PROPERTY@odata.bind": "/msdyn_projecttasks(PREDECESSOR_GUID)",
  "SUCCESSOR_NAVIGATION_PROPERTY@odata.bind": "/msdyn_projecttasks(SUCCESSOR_GUID)",
  "msdyn_linktype": 192350000
}
```

Replace the navigation-property placeholders with exact names from tenant `$metadata` or the tool schema. Do not copy capitalization from an unrelated environment.

Conceptual dependency replacement:

```text
CreateOperationSet(project, description)
PssDelete(old_dependency_id, "msdyn_projecttaskdependency", operation_set)
PssCreate(new_dependency_entity, operation_set)
ExecuteOperationSet(operation_set)
```

Prefer V2 create/update when batching several homogeneous entity payloads, but count every entity toward the 200-operation cap. Chunking across OperationSets loses whole-change atomicity; disclose that tradeoff and validate after each chunk.

For TypeScript or Python wrappers, keep compilation deterministic:

- LLM produces normalized intent with stable IDs.
- Validator enforces graph/domain invariants.
- Compiler converts validated operations to PSS payloads.
- Executor handles authentication, OperationSet lifecycle, polling, retries, and audit.
- Verifier re-reads and compares expected versus actual state.

## 5. Failure handling

| Failure point | Required behavior |
| --- | --- |
| Read/version mismatch | stop and refresh plan |
| Identity ambiguity | ask user to select exact task |
| Validation failure | do not create OperationSet |
| Queue failure before execute | abandon set, report no committed change |
| Execute failure | capture correlation/logs; do not claim rollback without evidence |
| Partial result | report each succeeded/failed record; stop further chunks |
| Timeout/unknown status | query operation status/logs; report unknown, not failed or succeeded |
| Post-write mismatch | report verification failure and prepare a compensating plan; do not silently retry |

Retries must be idempotent. Use client-provided entity IDs and an operation/audit identifier so the executor can detect prior success.
