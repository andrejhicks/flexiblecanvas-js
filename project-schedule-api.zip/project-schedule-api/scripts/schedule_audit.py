#!/usr/bin/env python3
"""Audit a Project Operations schedule snapshot without external dependencies.

Input is JSON with `tasks`, `dependencies`, and an optional `calendar`.
Run with --example to print the accepted shape or --self-test for a smoke test.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable
from zoneinfo import ZoneInfo


DAY_NAMES = {
    "monday": 0,
    "tuesday": 1,
    "wednesday": 2,
    "thursday": 3,
    "friday": 4,
    "saturday": 5,
    "sunday": 6,
}

LINK_TYPE_MAP = {
    192350000: "FS",
    192350001: "SS",
    192350002: "FF",
    192350004: "SF",
    1: "FS",
    2: "SS",
    3: "FF",
    4: "SF",
}


def parse_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        result = value
    else:
        text = str(value).strip()
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        try:
            result = datetime.fromisoformat(text)
        except ValueError as exc:
            raise ValueError(f"invalid ISO datetime: {value!r}") from exc
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result


def parse_time(value: str) -> time:
    return time.fromisoformat(value)


@dataclass(frozen=True)
class WorkCalendar:
    timezone_name: str = "UTC"
    working_days: tuple[int, ...] = (0, 1, 2, 3, 4)
    work_intervals: tuple[tuple[time, time], ...] = ((time(9), time(17)),)
    holidays: frozenset[date] = frozenset()
    minutes_per_day: int = 480

    @property
    def tz(self) -> ZoneInfo:
        return ZoneInfo(self.timezone_name)

    @classmethod
    def from_json(cls, raw: dict[str, Any] | None) -> "WorkCalendar":
        raw = raw or {}
        days: list[int] = []
        for item in raw.get("working_days", [0, 1, 2, 3, 4]):
            if isinstance(item, int):
                days.append(item)
            else:
                days.append(DAY_NAMES[str(item).lower()])
        intervals = tuple(
            (parse_time(pair[0]), parse_time(pair[1]))
            for pair in raw.get("work_intervals", [["09:00", "17:00"]])
        )
        holidays = frozenset(date.fromisoformat(x) for x in raw.get("holidays", []))
        minutes = raw.get("minutes_per_day")
        if minutes is None:
            minutes = int(sum(
                (datetime.combine(date.min, end) - datetime.combine(date.min, start)).total_seconds() / 60
                for start, end in intervals
            ))
        return cls(
            timezone_name=raw.get("timezone", "UTC"),
            working_days=tuple(sorted(set(days))),
            work_intervals=intervals,
            holidays=holidays,
            minutes_per_day=int(minutes),
        )

    def is_workday(self, day: date) -> bool:
        return day.weekday() in self.working_days and day not in self.holidays

    def intervals_for(self, day: date) -> list[tuple[datetime, datetime]]:
        if not self.is_workday(day):
            return []
        return [
            (datetime.combine(day, start, self.tz), datetime.combine(day, end, self.tz))
            for start, end in self.work_intervals
        ]

    def add_minutes(self, value: datetime, minutes: float) -> datetime:
        if minutes == 0:
            return value
        return self._add_forward(value, minutes) if minutes > 0 else self._add_backward(value, -minutes)

    def _add_forward(self, value: datetime, minutes: float) -> datetime:
        current = value.astimezone(self.tz)
        remaining = float(minutes)
        while remaining > 1e-9:
            candidates = [(start, end) for start, end in self.intervals_for(current.date()) if end > current]
            if not candidates:
                current = datetime.combine(current.date() + timedelta(days=1), time.min, self.tz)
                continue
            start, end = candidates[0]
            current = max(current, start)
            available = (end - current).total_seconds() / 60
            step = min(available, remaining)
            current += timedelta(minutes=step)
            remaining -= step
            if remaining > 1e-9 and current >= end:
                current = datetime.combine(current.date() + timedelta(days=1), time.min, self.tz)
        return current.astimezone(value.tzinfo or timezone.utc)

    def _add_backward(self, value: datetime, minutes: float) -> datetime:
        current = value.astimezone(self.tz)
        remaining = float(minutes)
        while remaining > 1e-9:
            candidates = [(start, end) for start, end in self.intervals_for(current.date()) if start < current]
            if not candidates:
                current = datetime.combine(current.date() - timedelta(days=1), time.max, self.tz)
                continue
            start, end = candidates[-1]
            current = min(current, end)
            available = (current - start).total_seconds() / 60
            step = min(available, remaining)
            current -= timedelta(minutes=step)
            remaining -= step
            if remaining > 1e-9 and current <= start:
                current = datetime.combine(current.date() - timedelta(days=1), time.max, self.tz)
        return current.astimezone(value.tzinfo or timezone.utc)

    def working_minutes_between(self, start: datetime, finish: datetime) -> float:
        if finish < start:
            return -self.working_minutes_between(finish, start)
        current_day = start.astimezone(self.tz).date()
        end_day = finish.astimezone(self.tz).date()
        start_local = start.astimezone(self.tz)
        finish_local = finish.astimezone(self.tz)
        total = 0.0
        while current_day <= end_day:
            for interval_start, interval_end in self.intervals_for(current_day):
                left = max(interval_start, start_local)
                right = min(interval_end, finish_local)
                if right > left:
                    total += (right - left).total_seconds() / 60
            current_day += timedelta(days=1)
        return total


def first_value(raw: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in raw and raw[key] not in (None, ""):
            return raw[key]
    return None


def task_id(raw: dict[str, Any]) -> str:
    return str(first_value(raw, "id", "task_id", "msdyn_projecttaskid") or "")


def task_name(raw: dict[str, Any]) -> str:
    return str(first_value(raw, "name", "subject", "msdyn_subject") or task_id(raw))


def task_start(raw: dict[str, Any]) -> datetime | None:
    return parse_datetime(first_value(raw, "start", "scheduled_start", "msdyn_scheduledstart", "msdyn_start"))


def task_finish(raw: dict[str, Any]) -> datetime | None:
    return parse_datetime(first_value(raw, "finish", "scheduled_end", "msdyn_scheduledend", "msdyn_finish"))


def task_duration_minutes(raw: dict[str, Any], calendar: WorkCalendar) -> float | None:
    value = first_value(raw, "scheduled_duration_minutes", "msdyn_scheduleddurationminutes", "duration_minutes")
    if value is not None:
        return float(value)
    value = first_value(raw, "duration_days", "duration", "msdyn_duration")
    if value is not None:
        return float(value) * calendar.minutes_per_day
    start, finish = task_start(raw), task_finish(raw)
    if start and finish:
        return calendar.working_minutes_between(start, finish)
    return None


def is_summary(raw: dict[str, Any]) -> bool:
    kind = str(first_value(raw, "task_type", "type") or "").lower()
    return bool(raw.get("is_summary")) or kind in {"summary", "module"}


def is_milestone(raw: dict[str, Any]) -> bool:
    kind = str(first_value(raw, "task_type", "type") or "").lower()
    return bool(raw.get("is_milestone")) or kind == "milestone"


def dependency_type(raw: dict[str, Any]) -> str:
    value = first_value(raw, "type", "dependency_type", "link_type", "msdyn_linktype")
    if isinstance(value, str) and value.upper() in {"FS", "SS", "FF", "SF"}:
        return value.upper()
    try:
        return LINK_TYPE_MAP[int(value)]
    except (TypeError, ValueError, KeyError):
        return str(value or "UNKNOWN").upper()


def dependency_lag_minutes(raw: dict[str, Any], calendar: WorkCalendar) -> float:
    value = first_value(raw, "lag_minutes")
    if value is not None:
        return float(value)
    value = first_value(raw, "lag_days", "lag")
    if value is not None:
        return float(value) * calendar.minutes_per_day
    return 0.0


def dependency_endpoints(raw: dict[str, Any]) -> tuple[str, str]:
    pred = first_value(raw, "predecessor_id", "predecessor_task_id", "msdyn_predecessortask")
    succ = first_value(raw, "successor_id", "successor_task_id", "msdyn_successortask")
    return str(pred or ""), str(succ or "")


def issue(code: str, severity: str, message: str, **details: Any) -> dict[str, Any]:
    result = {"code": code, "severity": severity, "message": message}
    if details:
        result["details"] = details
    return result


def find_cycles(nodes: Iterable[str], edges: dict[str, set[str]]) -> list[list[str]]:
    color: dict[str, int] = {node: 0 for node in nodes}
    stack: list[str] = []
    cycles: list[list[str]] = []

    def visit(node: str) -> None:
        color[node] = 1
        stack.append(node)
        for nxt in edges.get(node, set()):
            if color.get(nxt, 0) == 0:
                visit(nxt)
            elif color.get(nxt) == 1:
                index = stack.index(nxt)
                cycle = stack[index:] + [nxt]
                if cycle not in cycles:
                    cycles.append(cycle)
        stack.pop()
        color[node] = 2

    for node in nodes:
        if color[node] == 0:
            visit(node)
    return cycles


def audit(snapshot: dict[str, Any]) -> dict[str, Any]:
    calendar = WorkCalendar.from_json(snapshot.get("calendar"))
    tolerance = float(snapshot.get("tolerance_minutes", 1))
    gap_threshold = float(snapshot.get("gap_threshold_minutes", calendar.minutes_per_day))
    tasks_raw = snapshot.get("tasks", [])
    deps_raw = snapshot.get("dependencies", [])
    issues: list[dict[str, Any]] = []

    tasks: dict[str, dict[str, Any]] = {}
    for raw in tasks_raw:
        identifier = task_id(raw)
        if not identifier:
            issues.append(issue("TASK_ID_MISSING", "error", "A task has no stable ID.", task=raw))
            continue
        if identifier in tasks:
            issues.append(issue("TASK_ID_DUPLICATE", "error", f"Duplicate task ID {identifier}."))
            continue
        tasks[identifier] = raw

    edges: dict[str, set[str]] = defaultdict(set)
    incoming_bounds: dict[str, list[tuple[datetime, str]]] = defaultdict(list)
    seen_edges: set[tuple[str, str, str, float]] = set()

    for index, raw in enumerate(deps_raw):
        dep_id = str(first_value(raw, "id", "dependency_id", "msdyn_projecttaskdependencyid") or index)
        pred_id, succ_id = dependency_endpoints(raw)
        dep_type = dependency_type(raw)
        lag = dependency_lag_minutes(raw, calendar)
        if not pred_id or not succ_id:
            issues.append(issue("DEPENDENCY_ENDPOINT_MISSING", "error", f"Dependency {dep_id} lacks an endpoint."))
            continue
        if pred_id == succ_id:
            issues.append(issue("DEPENDENCY_SELF_LINK", "error", f"Dependency {dep_id} links task {pred_id} to itself."))
        if pred_id not in tasks or succ_id not in tasks:
            issues.append(issue("DEPENDENCY_ORPHAN", "error", f"Dependency {dep_id} references a missing task.", predecessor_id=pred_id, successor_id=succ_id))
            continue
        if dep_type not in {"FS", "SS", "FF", "SF"}:
            issues.append(issue("DEPENDENCY_TYPE_UNKNOWN", "error", f"Dependency {dep_id} has unsupported type {dep_type}."))
            continue
        signature = (pred_id, succ_id, dep_type, lag)
        if signature in seen_edges:
            issues.append(issue("DEPENDENCY_DUPLICATE", "warning", f"Dependency {dep_id} duplicates an existing edge."))
        seen_edges.add(signature)
        pred, succ = tasks[pred_id], tasks[succ_id]
        if is_summary(pred) or is_summary(succ):
            issues.append(issue("SUMMARY_DEPENDENCY_ENDPOINT", "error", f"Dependency {dep_id} uses a summary task endpoint."))
        pred_module = first_value(pred, "module_id")
        succ_module = first_value(succ, "module_id")
        if pred_module and succ_module and pred_module != succ_module:
            issues.append(issue("CROSS_MODULE_DEPENDENCY", "error", f"Dependency {dep_id} crosses module boundaries.", predecessor_module=pred_module, successor_module=succ_module))
        edges[pred_id].add(succ_id)

        pred_start, pred_finish = task_start(pred), task_finish(pred)
        succ_start, succ_finish = task_start(succ), task_finish(succ)
        reference = pred_finish if dep_type in {"FS", "FF"} else pred_start
        actual = succ_start if dep_type in {"FS", "SS"} else succ_finish
        if reference is None or actual is None:
            issues.append(issue("DEPENDENCY_DATE_UNVERIFIABLE", "warning", f"Dependency {dep_id} lacks required dates."))
            continue
        required = calendar.add_minutes(reference, lag)
        delta = calendar.working_minutes_between(required, actual)
        if delta < -tolerance:
            issues.append(issue("DEPENDENCY_DATE_VIOLATION", "error", f"Dependency {dep_id} is violated by {-delta:.1f} working minutes.", required=required.isoformat(), actual=actual.isoformat(), type=dep_type))

        duration = task_duration_minutes(succ, calendar)
        implied_start = required
        if dep_type in {"FF", "SF"} and duration is not None:
            implied_start = calendar.add_minutes(required, -duration)
        incoming_bounds[succ_id].append((implied_start, dep_id))

    for cycle in find_cycles(tasks.keys(), edges):
        issues.append(issue("DEPENDENCY_CYCLE", "error", "Dependency graph contains a cycle.", cycle=cycle))

    for identifier, raw in tasks.items():
        name = task_name(raw)
        start, finish = task_start(raw), task_finish(raw)
        duration = task_duration_minutes(raw, calendar)
        if start and finish and finish < start:
            issues.append(issue("TASK_FINISH_BEFORE_START", "error", f"Task {name} finishes before it starts.", task_id=identifier))
        if is_milestone(raw) and duration is not None and abs(duration) > tolerance:
            issues.append(issue("MILESTONE_NONZERO_DURATION", "error", f"Milestone {name} has nonzero duration.", task_id=identifier, duration_minutes=duration))
        if start and finish and duration is not None and not is_summary(raw):
            actual_duration = calendar.working_minutes_between(start, finish)
            if abs(actual_duration - duration) > tolerance:
                issues.append(issue("TASK_DURATION_DATE_MISMATCH", "warning", f"Task {name} dates do not match its working duration.", task_id=identifier, stated_minutes=duration, date_minutes=actual_duration))

        if start and incoming_bounds.get(identifier):
            strongest, dep_id = max(incoming_bounds[identifier], key=lambda item: item[0])
            gap = calendar.working_minutes_between(strongest, start)
            if gap > gap_threshold:
                known_driver = any(first_value(raw, key) for key in (
                    "constraint_type", "constraint_date", "anchor_id", "start_anchor_id",
                    "manual_date_lock", "locked", "resource_driven", "has_actuals", "progress",
                ))
                code = "EXPLAINED_DATE_GAP" if known_driver else "POSSIBLE_UI_CONSTRAINT"
                severity = "info" if known_driver else "warning"
                message = (
                    f"Task {name} starts {gap:.1f} working minutes after its strongest network bound; "
                    + ("a recorded driver may explain the gap." if known_driver else "no recorded driver explains the gap.")
                )
                issues.append(issue(code, severity, message, task_id=identifier, dependency_id=dep_id, network_start=strongest.isoformat(), scheduled_start=start.isoformat()))

    parent_children: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for raw in tasks.values():
        parent = first_value(raw, "parent_id", "parent_task_id", "msdyn_parenttask")
        if parent:
            parent_children[str(parent)].append(raw)
    for parent_id, children in parent_children.items():
        parent = tasks.get(parent_id)
        if not parent or not is_summary(parent):
            continue
        child_starts = [task_start(x) for x in children if task_start(x)]
        child_finishes = [task_finish(x) for x in children if task_finish(x)]
        if child_starts and task_start(parent) and abs(calendar.working_minutes_between(min(child_starts), task_start(parent))) > tolerance:
            issues.append(issue("SUMMARY_START_ROLLUP_MISMATCH", "warning", f"Summary {task_name(parent)} start does not match its earliest child.", task_id=parent_id))
        if child_finishes and task_finish(parent) and abs(calendar.working_minutes_between(max(child_finishes), task_finish(parent))) > tolerance:
            issues.append(issue("SUMMARY_FINISH_ROLLUP_MISMATCH", "warning", f"Summary {task_name(parent)} finish does not match its latest child.", task_id=parent_id))

    counts = {level: sum(1 for item in issues if item["severity"] == level) for level in ("error", "warning", "info")}
    return {
        "project_id": snapshot.get("project_id"),
        "snapshot_version": snapshot.get("snapshot_version"),
        "task_count": len(tasks),
        "dependency_count": len(deps_raw),
        "calendar": {
            "timezone": calendar.timezone_name,
            "working_days": list(calendar.working_days),
            "minutes_per_day": calendar.minutes_per_day,
        },
        "counts": counts,
        "issues": issues,
        "status": "invalid" if counts["error"] else ("review" if counts["warning"] else "valid"),
    }


EXAMPLE = {
    "project_id": "PROJECT_GUID",
    "snapshot_version": "opaque-version",
    "tolerance_minutes": 1,
    "gap_threshold_minutes": 480,
    "calendar": {
        "timezone": "America/Chicago",
        "working_days": ["monday", "tuesday", "wednesday", "thursday", "friday"],
        "work_intervals": [["08:00", "12:00"], ["13:00", "17:00"]],
        "holidays": [],
        "minutes_per_day": 480,
    },
    "tasks": [
        {"id": "A", "name": "Task A", "module_id": "M1", "start": "2026-08-17T08:00:00-05:00", "finish": "2026-08-18T17:00:00-05:00", "duration_days": 2},
        {"id": "B", "name": "Task B", "module_id": "M1", "start": "2026-08-24T08:00:00-05:00", "finish": "2026-08-24T17:00:00-05:00", "duration_days": 1},
    ],
    "dependencies": [
        {"id": "D1", "predecessor_id": "A", "successor_id": "B", "type": "FS", "lag_minutes": 0}
    ],
}


def self_test() -> None:
    result = audit(EXAMPLE)
    assert result["status"] == "review"
    assert any(item["code"] == "POSSIBLE_UI_CONSTRAINT" for item in result["issues"])

    explained = json.loads(json.dumps(EXAMPLE))
    explained["tasks"][1]["constraint_type"] = "SNET"
    result = audit(explained)
    assert any(item["code"] == "EXPLAINED_DATE_GAP" for item in result["issues"])
    assert not any(item["code"] == "POSSIBLE_UI_CONSTRAINT" for item in result["issues"])

    violation = json.loads(json.dumps(EXAMPLE))
    violation["tasks"][1]["start"] = "2026-08-18T08:00:00-05:00"
    violation["tasks"][1]["finish"] = "2026-08-18T17:00:00-05:00"
    result = audit(violation)
    assert any(item["code"] == "DEPENDENCY_DATE_VIOLATION" for item in result["issues"])

    cycle = json.loads(json.dumps(EXAMPLE))
    cycle["dependencies"].append({"id": "D2", "predecessor_id": "B", "successor_id": "A", "type": "FS"})
    result = audit(cycle)
    assert any(item["code"] == "DEPENDENCY_CYCLE" for item in result["issues"])

    invalid_endpoint = json.loads(json.dumps(EXAMPLE))
    invalid_endpoint["tasks"][0]["is_summary"] = True
    invalid_endpoint["tasks"][1]["module_id"] = "M2"
    result = audit(invalid_endpoint)
    assert any(item["code"] == "SUMMARY_DEPENDENCY_ENDPOINT" for item in result["issues"])
    assert any(item["code"] == "CROSS_MODULE_DEPENDENCY" for item in result["issues"])


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit a Project Operations schedule snapshot JSON file.")
    parser.add_argument("input", nargs="?", help="Input JSON path, or - for stdin")
    parser.add_argument("--output", "-o", help="Write JSON report to this path; default stdout")
    parser.add_argument("--example", action="store_true", help="Print an example input document")
    parser.add_argument("--self-test", action="store_true", help="Run built-in smoke tests")
    args = parser.parse_args()

    if args.example:
        print(json.dumps(EXAMPLE, indent=2))
        return 0
    if args.self_test:
        self_test()
        print("schedule_audit self-test passed")
        return 0
    if not args.input:
        parser.error("input is required unless --example or --self-test is used")

    if args.input == "-":
        snapshot = json.load(sys.stdin)
    else:
        snapshot = json.loads(Path(args.input).read_text(encoding="utf-8"))
    report = audit(snapshot)
    rendered = json.dumps(report, indent=2)
    if args.output:
        Path(args.output).write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)
    return 2 if report["counts"]["error"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
