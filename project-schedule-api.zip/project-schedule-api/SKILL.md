---
name: project-schedule-api
description: Inspect, reason about, audit, simulate, and safely modify Microsoft Dynamics 365 Project Operations schedules through the Project Schedule API or a service wrapper. Use for Project Operations project tasks, WBS hierarchies, task durations, start/finish dates, Project Task Dependency records, FS/SS/FF/SF relationships, lag or lead, schedule modes, OperationSets, Project Scheduling Service errors, natural-language schedule changes, date/dependency misalignment, UI-created date constraints, or project-template schedule publication.
---

# Project Schedule API

Treat the Project Scheduling Service (PSS) as the scheduling authority. Read the complete schedule and translate user language into typed scheduling intent before compiling API operations. Prefer changing scheduling drivers—duration, dependency, calendar, assignment, or an explicit constraint—over writing calculated dates.

## Load the right guidance

- Read [references/project-operations-api.md](references/project-operations-api.md) before compiling or executing PSS operations.
- Read [references/schedule-reasoning.md](references/schedule-reasoning.md) when interpreting dates, durations, dependencies, constraints, or natural-language requests.
- Read [references/service-contract.md](references/service-contract.md) when binding the workflow to tools, a custom schedule service, Power Automate, Dataverse Web API, TypeScript, or C#.
- Run `scripts/schedule_audit.py` when a schedule snapshot is available as JSON and deterministic graph/date checks would help.

## Non-negotiable rules

1. Read before changing. Resolve the project, current version/revision, task IDs, hierarchy, schedule mode, calendar, dates, durations, dependencies, constraints or anchors, assignments, and locks.
2. Use stable IDs. Never select a task by name when the name is duplicated or ambiguous.
3. Treat scheduled dates as outputs unless the user explicitly requests a real date constraint or anchor.
4. Never write `msdyn_start`, `msdyn_scheduledstart`, `msdyn_finish`, or `msdyn_scheduledend` merely to move a dependency-driven task. A direct date write can create constraint behavior or disrupt the dependency network.
5. Snapshot all incident dependencies before any task date mutation and verify them afterward.
6. Update a dependency by deleting its existing `msdyn_projecttaskdependency` row and creating a replacement; PSS does not support dependency-row update.
7. Use a single OperationSet for one atomic schedule change when the operation count allows it. Do not exceed 200 operations or leave an unneeded open set.
8. Show the final diff and obtain explicit approval before a live schedule write. Read-only inspection and simulation need no confirmation.
9. Stop on version conflict, ambiguous target, cycle, invalid endpoint, failed operation, or partial result. Never claim success until post-write verification passes.
10. Preserve unknown fields and unrelated schedule state. Send minimal entity payloads containing the ID and changed fields.

For Andre's template-scheduling workflows, also enforce these hard rules:

- Keep every dependency inside one summary-task module.
- Reject summary tasks as dependency endpoints; allow only leaf tasks and milestones.
- Preserve global tasks, locked values, and locked relationships.
- Resolve task and start-integration exclusions before dependency reasoning.
- Keep rig-relative timing intent separate from task-ordering intent.
- Test the supported country/project-type matrix before publishing template changes.

## Required workflow

### 1. Resolve intent and scope

Convert the request into a typed plan:

- target project and module or task set;
- requested task, duration, dependency, hierarchy, assignment, or constraint change;
- hard requirements versus soft preferences;
- working-day or calendar-day basis;
- expected schedule effect;
- fields that must remain unchanged.

Ask only when an ambiguity changes the schedule semantics. For example, “move Task B to Monday” could mean add a Start No Earlier Than constraint, change its predecessor, change lag, or change duration. Do not guess.

### 2. Read a coherent snapshot

Read tasks, dependencies, hierarchy, project and task schedule modes, calendars, assignments, explicit constraint/anchor metadata, percent complete, actuals, locks, and a version token in one logical snapshot. If the service cannot return a coherent snapshot, retain retrieval timestamps and re-read before execution.

For template work, filter exclusions and resolve the one active start-date integration record per required anchor group before analyzing the graph.

### 3. Audit and explain

Validate:

- missing, duplicate, self, cross-project, cross-module, or summary-task dependency endpoints;
- cycles and redundant edges;
- duration/date inconsistencies and milestone duration;
- dependency boundary violations;
- unexplained positive gaps between network-driven and scheduled dates;
- constraints, anchors, progress, calendars, resource availability, or manual locks that can explain those gaps;
- schedule and platform limits.

Classify an unexplained gap as a **possible UI-driven constraint**, not proof. Confirm it from constraint fields, audit history, a controlled simulation, or a UI inspection before removing it.

### 4. Simulate the smallest valid change

Prefer a minimal change that directly expresses the user intent. Simulate the complete diff, including cascading dates, affected dependencies, critical-path movement, and module finish. Do not optimize the entire schedule when the user requested a local change.

### 5. Present a reviewable diff

Show:

- exact task/dependency IDs and human names;
- current versus proposed values;
- reason for every operation;
- predicted date changes and downstream impact;
- validation results and unresolved assumptions;
- planned PSS action sequence and operation count.

### 6. Execute safely

After explicit approval:

1. Re-read the version token and affected records.
2. Create an OperationSet.
3. Queue dependency deletes before replacement creates; queue minimal task updates.
4. Execute the OperationSet.
5. Poll or query the service/logs until the outcome is known.
6. Abandon an unexecuted set after a pre-execution failure.
7. Re-read affected tasks and every incident dependency.
8. Re-run structural and date-alignment validation.

If the wrapper performs OperationSet handling internally, still require equivalent atomicity, per-record results, correlation IDs, and post-write verification.

## Response contract

For analysis or proposed changes, return:

```text
Scope
- Project / module / tasks:
- Snapshot version:

Current schedule
- Dependencies and durations:
- Date or constraint findings:

Requested intent
- Hard requirements:
- Assumptions requiring confirmation:

Proposed changes
- Create:
- Update:
- Delete:
- Preserve:

Predicted effect
- Changed dates:
- Downstream impact:

Validation
- Cycles / invalid endpoints / date violations:
- Possible UI constraints:
- Operation count and limits:

Next action
- Inspect / approve live write / resolve blocker
```

For execution, report the OperationSet or correlation identifier, per-record outcome, post-write values, and whether verification passed.
