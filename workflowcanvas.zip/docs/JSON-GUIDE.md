# The diagram file, field by field

A diagram is one JSON file. Only `nodes` and `edges` are required; everything
else adds polish.

```json
{
  "$schema": "../docs/workflow.schema.json",
  "meta":   { },
  "layout": { },
  "groups": [ ],
  "nodes":  [ ],
  "edges":  [ ]
}
```

Keep the `$schema` line. It costs nothing and gives you autocomplete, hover
docs and typo detection in VS Code and most other editors.

---

## `meta`

Rendered as a title block above the diagram and captured in the export.

```json
"meta": {
  "title": "Member Intake: Current State",
  "subtitle": "v2.1 · reviewed 4 Aug 2026",
  "owner": "Product Architecture",
  "footnote": "Timings are targets, not measurements.",
  "showLegend": true
}
```

| Field | Notes |
| --- | --- |
| `title` | The headline. Say what the diagram is *of* and what state it shows. |
| `subtitle` | Version and date. Saves you from arguing about a stale printout six weeks later. |
| `owner` | Who to ask. Rendered small, in caps. |
| `footnote` | Bottom-left caption. The place for the caveat that stops the meeting derailing. |
| `showLegend` | `false` hides the key. Do that only when the audience already knows your notation. |

---

## `layout`

Applied to nodes that have no `position` of their own.

```json
"layout": {
  "direction": "LR",
  "nodeSpacing": 44,
  "rankSpacing": 150
}
```

| Field | Default | Notes |
| --- | --- | --- |
| `direction` | `"LR"` | `LR`, `RL`, `TB`, `BT`. `LR` for process flows, `TB` for decision trees. |
| `nodeSpacing` | `48` | Gap between siblings, px. |
| `rankSpacing` | `130` | Gap between columns (`LR`) or rows (`TB`), px. Raise it when edge labels collide. |
| `align` | unset | Dagre hint: `UL`, `UR`, `DL`, `DR`. Rarely needed. |

You can flip direction live from the **Flow** dropdown to see which reads
better before writing it into the file.

---

## `groups`

Swimlanes. Optional, but they do more for comprehension than any other single
field once you pass about twelve nodes.

```json
"groups": [
  { "id": "intake",    "label": "1 · Intake",    "color": "slate" },
  { "id": "discovery", "label": "2 · Discovery", "color": "violet" }
]
```

| Field | Notes |
| --- | --- |
| `id` | Referenced by a node's `group`. |
| `label` | Shown on the band. Numbering the phases (`1 ·`, `2 ·`) helps people follow along out loud. |
| `color` | `slate`, `blue`, `indigo`, `violet`, `teal`, `green`, `amber`, `rose`, `red`, or any CSS colour. |
| `description` | Not rendered on the band; available for your own notes. |

Group by **phase** or by **owning team**, not both in the same diagram.

---

## `nodes`

```json
{
  "id": "triage",
  "label": "Weekly triage",
  "kind": "manual",
  "subtitle": "30 min, Mondays",
  "group": "intake",
  "owner": "PM + Eng lead + Design",
  "system": "Linear",
  "duration": "1 week max in queue",
  "description": "Longer prose, shown when the card is clicked.",
  "details": [
    "Restate the request as a problem, not a solution",
    "Tag to an existing theme or open a new one"
  ],
  "metrics": [
    { "label": "Backlog age", "value": "9 d median", "tone": "warn" }
  ],
  "tags": ["Gate"],
  "status": "current",
  "link": "https://example.com/runbook",
  "position": { "x": 0, "y": 0 },
  "width": 280
}
```

### Required

| Field | Notes |
| --- | --- |
| `id` | Unique. Edges reference it. Short lowercase slugs age best. |
| `label` | The card title. A short verb phrase: "Validate the address", not "Address validation". |

### The card face

| Field | Where it shows |
| --- | --- |
| `subtitle` | One grey line under the title. Good for the system or the cadence. |
| `owner` | Meta row with a ◑ icon. A role, not a person's name: people change. |
| `system` | Meta row with a ⚙ icon. |
| `duration` | Meta row with a ◷ icon. Free text: `2 min`, `1-3 days`, `overnight`. |
| `details` | Bullets. The first three show on the card, the rest collapse to `+N more` and appear in full in the detail panel. |
| `metrics` | Stat chips. `tone` is `neutral`, `good`, `warn` or `bad`. |
| `tags` | Small pills. Use for `P0`, `Manual today`, `Needs owner`. |
| `emotion` | A colored chip under the title: `{ "label": "overwhelmed", "tone": "bad" }`. Tones match metrics. String these across a flow and you get a journey map's emotion curve, one node at a time. |
| `quote` | Verbatim user or persona voice, rendered as an italic pull-quote on the card. The single highest-signal field on a journey map. |

### Behaviour

| Field | Notes |
| --- | --- |
| `kind` | Colour, icon and shape. See the table below. |
| `group` | A group `id`. |
| `status` | `current` (default), `proposed` (dashed), `deprecated` (faded), `blocked` (red rail). |
| `description` | Paragraph, detail panel only. |
| `link` | URL, opened from the detail panel. |
| `position` | Pins the node. Omit to let auto-layout place it. **Save JSON** writes these for you. |
| `width` | Override the 280px card width. Widen a node that carries a long label rather than letting it wrap to four lines. |

### `kind`

| Value | Use for |
| --- | --- |
| `start` | Entry point |
| `process` | A step something does (the default) |
| `decision` | A branch: phrase `label` as a question |
| `system` | Something a named system does |
| `data` | A read, write, query or transform |
| `manual` | A human has to do this |
| `external` | Outside your control |
| `risk` | The step that breaks, or the one nobody owns |
| `end` | Terminal state |

`kind` and `status` are independent, which is the point: a `system` node can be
`proposed`, and that one diagram then shows current and future state together.

---

## `edges`

```json
{ "from": "triage", "to": "known", "label": "always" }
```

| Field | Notes |
| --- | --- |
| `from` | Source node `id`. Required. |
| `to` | Target node `id`. Required. |
| `label` | Sits on the line. Essential on every edge leaving a decision. |
| `kind` | See below. Default `default`. |
| `note` | Extra context, shown when the connection is clicked. |
| `animated` | Force marching ants on or off, overriding the kind's default. |
| `id` | Optional. Auto-generated as `from->to`. Only needed for two edges between the same pair. |

### `kind`

| Value | Renders as | Use for |
| --- | --- | --- |
| `default` | Solid grey | Sequence |
| `conditional` | Dashed amber | A branch. Always label it. |
| `async` | Dotted cyan, animated | Fire and forget |
| `error` | Dashed red | The failure path |
| `data` | Solid violet, heavier | Data moving |
| `feedback` | Dotted grey | A loop back. Laid out so it doesn't stretch the diagram sideways. |

Use `feedback` for any edge that points backwards. A plain `default` back-edge
makes dagre stretch the whole diagram to accommodate it.

---

## Worked example

A decision with both branches, a failure path and a retry loop:

```json
{
  "$schema": "../docs/workflow.schema.json",
  "meta": { "title": "Document Intake", "subtitle": "Current state" },
  "layout": { "direction": "LR" },
  "groups": [
    { "id": "capture", "label": "Capture", "color": "blue" },
    { "id": "extract", "label": "Extract", "color": "violet" }
  ],
  "nodes": [
    { "id": "upload", "label": "Caregiver uploads a document",
      "kind": "start", "group": "capture", "subtitle": "PDF or photo" },

    { "id": "ocr", "label": "OCR and layout analysis",
      "kind": "system", "group": "extract",
      "system": "Document Intelligence", "duration": "~8 s",
      "details": ["Handles handwriting poorly", "Retries once on timeout"],
      "metrics": [{ "label": "Success", "value": "94%", "tone": "good" }] },

    { "id": "confident", "label": "Confident in the extraction?",
      "kind": "decision", "group": "extract" },

    { "id": "review", "label": "Human review queue",
      "kind": "manual", "group": "extract",
      "owner": "Ops", "duration": "1-2 days",
      "tags": ["Bottleneck"],
      "metrics": [{ "label": "Queue", "value": "40+", "tone": "bad" }] },

    { "id": "store", "label": "Stored and searchable",
      "kind": "end", "group": "extract" }
  ],
  "edges": [
    { "from": "upload",    "to": "ocr" },
    { "from": "ocr",       "to": "confident" },
    { "from": "confident", "to": "store",  "label": "yes", "kind": "conditional" },
    { "from": "confident", "to": "review", "label": "no",  "kind": "conditional" },
    { "from": "review",    "to": "store",  "label": "corrected" },
    { "from": "review",    "to": "ocr",    "label": "re-run", "kind": "feedback",
      "note": "Only when the original scan was the problem." }
  ]
}
```

---

## Pattern: user journey maps

The same format handles journey maps well. The mapping that works:

| Journey concept | Field to use |
| --- | --- |
| Stage (Awareness, First use, ...) | `groups`, numbered labels |
| Touchpoint or action | A node; `manual` for what the person does, `system` for what the product does |
| Emotional state | `emotion` on each node; the tones draw the curve |
| Verbatim voice | `quote` |
| Pain point | `kind: "risk"` |
| Drop-off exit | A `kind: "end"` node hanging off a decision, with the risk noted in `metrics` |
| Re-entry or repeat use | A `feedback` edge |
| Future-state opportunity | `status: "proposed"` plus a `Planned` tag |

Two rules of thumb. First, keep the persona honest: put "illustrative persona,
not research data" in the `footnote` unless every quote came from a real
session. Second, mark anything unshipped as `proposed`; a journey map that
silently blends current and future state will be read as a claim about today.

See `workflows/04-caregiver-journey.json` for a complete worked example.

---

## Things that trip people up

**JSON has no comments.** `//` breaks the file. Park notes in a `note` field
on an edge or a `description` on a node.

**No trailing commas.** The most common parse error by a wide margin. The
editor pane tells you the line and column.

**Ids are case-sensitive.** `"from": "OCR"` will not match `"id": "ocr"`. The
app reports it rather than silently dropping the edge.

**A node with no edges is almost always a typo.** The validator flags every
orphan for exactly this reason.

**Positions are all-or-nothing per node.** `{ "x": 100 }` without `y` is
ignored and the node goes back to auto-layout.

**Diagrams get wide fast.** Twenty steps at 280px each is roughly 7,000px.
Switch to `TB`, split at a natural seam, or pin positions to wrap it into two
rows. It is a property of the content, not a setting you can turn off.
