import { ReactFlowProvider } from '@xyflow/react'
import Canvas from './components/Canvas.jsx'

export default function App() {
  return (
    <ReactFlowProvider>
      <Canvas />
    </ReactFlowProvider>
  )
}
