import { memo } from 'react'
import { Handle, Position } from '@xyflow/react'
import { kindStyle, METRIC_TONES } from '../lib/theme.js'

const HANDLES = {
  LR: { target: Position.Left, source: Position.Right },
  RL: { target: Position.Right, source: Position.Left },
  TB: { target: Position.Top, source: Position.Bottom },
  BT: { target: Position.Bottom, source: Position.Top },
}

// Loop-back edges get their own pair of handles on the side the flow does not
// use. Without them a back-edge leaves the right handle, has to travel the
// whole diagram leftwards, and lands exactly on top of the forward path it is
// returning along — a loop you cannot see is worse than no loop at all.
const LOOP_SIDE = {
  LR: Position.Bottom,
  RL: Position.Bottom,
  TB: Position.Right,
  BT: Position.Right,
}

function DetailNode({ data, selected }) {
  const k = kindStyle(data.kind)
  const dir = HANDLES[data.direction] || HANDLES.LR
  const loopSide = LOOP_SIDE[data.direction] || Position.Bottom
  const loopHorizontal = loopSide === Position.Bottom
  const isDiamond = k.shape === 'diamond'
  const isPill = k.shape === 'pill'

  const metaRows = [
    data.owner && { icon: '◑', text: data.owner },
    data.system && { icon: '⚙', text: data.system },
    data.duration && { icon: '◷', text: data.duration },
  ].filter(Boolean)

  const bullets = (data.details || []).slice(0, 3)
  const hiddenBullets = Math.max(0, (data.details || []).length - bullets.length)

  return (
    <div
      className={[
        'wf-node',
        `wf-node--${k.shape}`,
        `wf-status--${data.status || 'current'}`,
        selected ? 'is-selected' : '',
      ].join(' ')}
      style={{
        width: data.width || 280,
        '--accent': k.accent,
        '--soft': k.soft,
        '--edge': k.border,
      }}
    >
      <Handle id="in" type="target" position={dir.target} className="wf-handle" />
      <Handle
        id="loop-t"
        type="target"
        position={loopSide}
        className="wf-handle wf-handle--loop"
        style={loopHorizontal ? { left: '68%' } : { top: '68%' }}
      />

      <div className="wf-node__rail" />

      <div className="wf-node__body">
        <div className="wf-node__kind">
          <span className="wf-node__icon" aria-hidden="true">{k.icon}</span>
          <span>{isDiamond ? 'Decision' : k.label}</span>
          {data.status && data.status !== 'current' && (
            <span className="wf-node__status">{data.status}</span>
          )}
        </div>

        <div className={isPill || isDiamond ? 'wf-node__title wf-node__title--lg' : 'wf-node__title'}>
          {data.label}
        </div>

        {data.subtitle && <div className="wf-node__subtitle">{data.subtitle}</div>}

        {data.emotion && (() => {
          const t = METRIC_TONES[data.emotion.tone] || METRIC_TONES.neutral
          return (
            <div className="wf-node__emotion" style={{ background: t.bg, color: t.fg }}>
              <span className="wf-node__emotiondot" aria-hidden="true" />
              {data.emotion.label}
            </div>
          )
        })()}

        {data.quote && <div className="wf-node__quote">&ldquo;{data.quote}&rdquo;</div>}

        {metaRows.length > 0 && (
          <div className="wf-node__meta">
            {metaRows.map((r, i) => (
              <div key={i} className="wf-node__metarow">
                <span className="wf-node__metaicon" aria-hidden="true">{r.icon}</span>
                <span>{r.text}</span>
              </div>
            ))}
          </div>
        )}

        {bullets.length > 0 && (
          <ul className="wf-node__bullets">
            {bullets.map((b, i) => (
              <li key={i}>{b}</li>
            ))}
            {hiddenBullets > 0 && <li className="wf-node__more">+{hiddenBullets} more</li>}
          </ul>
        )}

        {(data.metrics || []).length > 0 && (
          <div className="wf-node__metrics">
            {data.metrics.map((m, i) => {
              const tone = METRIC_TONES[m.tone] || METRIC_TONES.neutral
              return (
                <div key={i} className="wf-node__metric" style={{ background: tone.bg, color: tone.fg }}>
                  <span className="wf-node__metricval">{m.value}</span>
                  <span className="wf-node__metriclabel">{m.label}</span>
                </div>
              )
            })}
          </div>
        )}

        {(data.tags || []).length > 0 && (
          <div className="wf-node__tags">
            {data.tags.map((t, i) => (
              <span key={i} className="wf-node__tag">{t}</span>
            ))}
          </div>
        )}
      </div>

      <Handle id="out" type="source" position={dir.source} className="wf-handle" />
      <Handle
        id="loop-s"
        type="source"
        position={loopSide}
        className="wf-handle wf-handle--loop"
        style={loopHorizontal ? { left: '32%' } : { top: '32%' }}
      />
    </div>
  )
}

export default memo(DetailNode)
