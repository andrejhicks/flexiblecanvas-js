import { useRef } from 'react'

export default function Toolbar({
  files, currentFile, onPickFile, onUploadFile,
  direction, onDirection,
  scale, onScale,
  area, onArea,
  transparent, onTransparent,
  showLanes, onShowLanes,
  showLegend, onShowLegend,
  trackpad, onTrackpad,
  onRelayout, onFit, onDownload, onCopy, onSaveJson, onToggleJson,
  busy, status, problemCount, preview,
}) {
  const fileInput = useRef(null)

  return (
    <div className="wf-toolbar no-export">
      <div className="wf-toolbar__row">
        <div className="wf-brand">
          <span className="wf-brand__mark" />
          Workflow Canvas
        </div>

        <Sep />

        <label className="wf-ctl">
          <span>Diagram</span>
          <select value={currentFile} onChange={(e) => onPickFile(e.target.value)}>
            {files.map((f) => (
              <option key={f.path} value={f.path}>{f.name}</option>
            ))}
            {!files.some((f) => f.path === currentFile) && (
              <option value={currentFile}>{currentFile}</option>
            )}
          </select>
        </label>

        <button className="wf-btn" onClick={() => fileInput.current?.click()} title="Open a .json file from anywhere on disk">
          Open…
        </button>
        <input
          ref={fileInput}
          type="file"
          accept="application/json,.json"
          style={{ display: 'none' }}
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) onUploadFile(f)
            e.target.value = ''
          }}
        />

        <button className="wf-btn" onClick={onToggleJson}>
          Edit JSON
          {problemCount > 0 && <span className="wf-badge">{problemCount}</span>}
        </button>

        <Sep />

        <label className="wf-ctl">
          <span>Flow</span>
          <select value={direction} onChange={(e) => onDirection(e.target.value)}>
            <option value="LR">Left → right</option>
            <option value="TB">Top → bottom</option>
            <option value="RL">Right → left</option>
            <option value="BT">Bottom → top</option>
          </select>
        </label>

        <button className="wf-btn" onClick={onRelayout} title="Re-run auto-layout, discarding manual drags">
          Re-layout
        </button>
        <button className="wf-btn" onClick={onFit} title="Fit the whole board on screen (F)">
          Fit
        </button>
      </div>

      <div className="wf-toolbar__row">
        <label className="wf-ctl">
          <span>Export</span>
          <select value={area} onChange={(e) => onArea(e.target.value)}>
            <option value="board">Whole board</option>
            <option value="view">Current view</option>
          </select>
        </label>

        <label className="wf-ctl">
          <span>at</span>
          <select value={scale} onChange={(e) => onScale(Number(e.target.value))}>
            <option value={1}>1× · web</option>
            <option value={2}>2× · slides</option>
            <option value={3}>3× · print</option>
            <option value={4}>4× · poster</option>
          </select>
        </label>

        {preview && (
          <span
            className={`wf-preview${preview.clamped ? ' wf-preview--capped' : ''}`}
            title={
              preview.clamped
                ? 'Too large for the requested scale: the browser caps a canvas near 16k px. Switch to Current view for a legible image.'
                : 'Exact pixel size of the next export'
            }
          >
            {preview.text}{preview.clamped ? ' capped' : ''}
          </span>
        )}

        <button className="wf-btn wf-btn--primary" onClick={onDownload} disabled={busy}>
          {busy === 'download' ? 'Rendering…' : 'Download PNG'}
        </button>
        <button className="wf-btn wf-btn--primary" onClick={onCopy} disabled={busy}>
          {busy === 'copy' ? 'Copying…' : 'Copy to clipboard'}
        </button>
        <button className="wf-btn" onClick={onSaveJson} title="Write current node positions back into the JSON and download it">
          Save JSON
        </button>

        <Sep />

        <Toggle checked={transparent} onChange={onTransparent} label="Transparent bg" />
        <Toggle checked={showLanes} onChange={onShowLanes} label="Lanes" />
        <Toggle checked={showLegend} onChange={onShowLegend} label="Legend" />
        <Toggle checked={trackpad} onChange={onTrackpad} label="Trackpad pan" title="Scroll pans, Ctrl+scroll zooms" />

        {status && <span className={`wf-status wf-status--${status.tone}`}>{status.text}</span>}
      </div>
    </div>
  )
}

function Sep() {
  return <span className="wf-sep" />
}

function Toggle({ checked, onChange, label, title }) {
  return (
    <label className="wf-toggle" title={title}>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  )
}
