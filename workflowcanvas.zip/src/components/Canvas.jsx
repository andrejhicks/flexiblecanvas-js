import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  ReactFlow,
  Background,
  BackgroundVariant,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  useReactFlow,
  useNodesInitialized,
  useUpdateNodeInternals,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'

import DetailNode from './DetailNode.jsx'
import LaneLayer from './LaneLayer.jsx'
import DiagramTitle from './DiagramTitle.jsx'
import Legend from './Legend.jsx'
import DetailPanel from './DetailPanel.jsx'
import JsonDrawer from './JsonDrawer.jsx'
import Toolbar from './Toolbar.jsx'

import { parseWorkflow, serializeWorkflow } from '../lib/parseWorkflow.js'
import { layoutGraph } from '../lib/layout.js'
import { computeFrame } from '../lib/frame.js'
import { exportPng, copyPng, downloadJson, planExport, viewportBounds } from '../lib/exportImage.js'
import { kindStyle } from '../lib/theme.js'

const nodeTypes = { detail: DetailNode }

// Every .json in /workflows shows up in the dropdown. Drop a file in that
// folder and Vite hot-reloads it straight into the picker.
const FILES = import.meta.glob('../../workflows/*.json', { eager: true })
const FILE_LIST = Object.entries(FILES)
  .map(([path, mod]) => ({ path, name: prettyName(path), doc: mod.default ?? mod }))
  .sort((a, b) => a.path.localeCompare(b.path))

function prettyName(path) {
  const base = path.split('/').pop().replace(/\.json$/, '')
  return base.replace(/^\d+[-_]/, '').replace(/[-_]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

const STORAGE_KEY = 'workflow-canvas:last'

// Decide what to open on load. Files listed in workflows/ are the source of
// truth on disk, so a saved reference to one of them reopens the FRESH copy
// rather than a stale snapshot; only ad-hoc uploads and JSON-drawer edits are
// restored verbatim.
const INITIAL = (() => {
  const saved = restore()
  if (saved?.file) {
    const listed = FILE_LIST.find((f) => f.path === saved.file)
    if (listed) return { file: listed.path, doc: listed.doc }
    if (saved.doc) return { file: saved.file, doc: saved.doc }
  }
  if (saved?.doc) return { file: 'unsaved edits', doc: saved.doc }
  return { file: FILE_LIST[0]?.path || '', doc: FILE_LIST[0]?.doc || { nodes: [], edges: [] } }
})()

export default function Canvas() {
  const [currentFile, setCurrentFile] = useState(INITIAL.file)
  const [sourceDoc, setSourceDoc] = useState(INITIAL.doc)
  const [jsonText, setJsonText] = useState(() => JSON.stringify(INITIAL.doc, null, 2))

  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [lanes, setLanes] = useState([])
  const [problems, setProblems] = useState([])
  const [selection, setSelection] = useState(null)

  const [direction, setDirection] = useState('LR')
  const [scale, setScale] = useState(2)
  const [area, setArea] = useState('board')
  const [transparent, setTransparent] = useState(false)
  const [showLanes, setShowLanes] = useState(true)
  const [showLegend, setShowLegend] = useState(true)
  const [trackpad, setTrackpad] = useState(false)
  const [jsonOpen, setJsonOpen] = useState(false)
  const [busy, setBusy] = useState(null)
  const [status, setStatus] = useState(null)

  const { fitBounds, fitView, getViewport } = useReactFlow()
  const updateNodeInternals = useUpdateNodeInternals()
  const paneRef = useRef(null)
  const nodesInitialized = useNodesInitialized()
  const measured = useRef(false)
  const parsedRef = useRef(null)

  // ---- parse ---------------------------------------------------------------
  const parsed = useMemo(() => parseWorkflow(sourceDoc), [sourceDoc])
  parsedRef.current = parsed

  useEffect(() => {
    measured.current = false
    setProblems(parsed.problems)
    setDirection(parsed.layout.direction)
    setShowLegend(parsed.meta.showLegend !== false)
    setSelection(null)

    const withDir = parsed.nodes.map((n) => ({ ...n, data: { ...n.data, direction: parsed.layout.direction } }))
    // First pass uses estimated heights so nothing flashes on top of itself.
    const first = layoutGraph({ nodes: withDir, edges: parsed.edges, layout: parsed.layout, groups: parsed.groups })
    setNodes(first.nodes)
    setEdges(parsed.edges)
    setLanes(first.lanes)
  }, [parsed, setNodes, setEdges])

  // ---- second pass, now that real card heights are known -------------------
  useEffect(() => {
    if (!nodesInitialized || measured.current || nodes.length === 0) return
    measured.current = true
    const p = parsedRef.current
    const result = layoutGraph({
      nodes,
      edges,
      layout: { ...p.layout, direction },
      groups: p.groups,
    })
    setNodes(result.nodes)
    setLanes(result.lanes)
    updateNodeInternals(result.nodes.map((n) => n.id))
  }, [nodesInitialized, nodes, edges, direction, setNodes, updateNodeInternals])

  // ---- measure where the edges actually run --------------------------------
  // React Flow tells us where nodes are but not where the wires go. A loop-back
  // edge can swing 200px below the lowest card, so the export frame has to be
  // told about it or the loop gets cropped.
  const [edgeBounds, setEdgeBounds] = useState(null)

  const measureEdges = useCallback(() => {
    const groups = document.querySelectorAll('g.react-flow__edge')
    if (groups.length === 0) return
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity
    groups.forEach((g) => {
      try {
        const b = g.getBBox()
        if (!b || (b.width === 0 && b.height === 0)) return
        x0 = Math.min(x0, b.x); y0 = Math.min(y0, b.y)
        x1 = Math.max(x1, b.x + b.width); y1 = Math.max(y1, b.y + b.height)
      } catch {
        /* a detached or hidden edge has no box; skip it */
      }
    })
    if (!Number.isFinite(x0)) return
    const next = { x: Math.floor(x0), y: Math.floor(y0), width: Math.ceil(x1 - x0), height: Math.ceil(y1 - y0) }
    setEdgeBounds((prev) =>
      prev && prev.x === next.x && prev.y === next.y && prev.width === next.width && prev.height === next.height
        ? prev
        : next
    )
  }, [])

  useEffect(() => {
    const id = requestAnimationFrame(() => requestAnimationFrame(measureEdges))
    return () => cancelAnimationFrame(id)
  }, [nodes, edges, measureEdges])

  // ---- the single source of truth for framing ------------------------------
  const frame = useMemo(
    () => computeFrame({ nodes, lanes, meta: parsed.meta, edges, edgeBounds, showLanes, showLegend }),
    [nodes, lanes, parsed.meta, edges, edgeBounds, showLanes, showLegend]
  )
  const frameRef = useRef(frame)
  frameRef.current = frame

  const fit = useCallback((duration = 350) => {
    const f = frameRef.current
    if (f?.outer) fitBounds(f.outer, { padding: 0.06, duration })
    else fitView({ padding: 0.15, duration })
  }, [fitBounds, fitView])

  // Auto-fit once, after the measured layout pass settles.
  const autoFitted = useRef(false)
  useEffect(() => {
    if (!measured.current || autoFitted.current || !frame?.outer) return
    autoFitted.current = true
    requestAnimationFrame(() => fit(400))
  }, [frame, fit])

  useEffect(() => { autoFitted.current = false }, [sourceDoc])

  // ---- keep lane bands glued to the cards while dragging -------------------
  const refreshLanes = useCallback(() => {
    const p = parsedRef.current
    if (!p || p.groups.length === 0) return
    setNodes((cur) => {
      const result = layoutGraph({
        nodes: cur.map((n) => ({ ...n, pinned: true })),
        edges,
        layout: { ...p.layout, direction },
        groups: p.groups,
      })
      setLanes(result.lanes)
      return cur
    })
    requestAnimationFrame(measureEdges)
  }, [edges, direction, setNodes, measureEdges])

  // ---- actions -------------------------------------------------------------
  const relayout = useCallback((dir = direction) => {
    const p = parsedRef.current
    const result = layoutGraph({
      nodes: nodes.map((n) => ({ ...n, pinned: false, data: { ...n.data, direction: dir } })),
      edges,
      layout: { ...p.layout, direction: dir },
      groups: p.groups,
      respectPins: false,
    })
    setNodes(result.nodes)
    setLanes(result.lanes)
    // Handles physically move when the flow direction changes. React Flow
    // caches handle coordinates, so without this the edges keep attaching to
    // where the handles used to be and the routing goes haywire.
    updateNodeInternals(result.nodes.map((n) => n.id))
    setTimeout(() => fit(400), 80)
  }, [nodes, edges, direction, setNodes, fit, updateNodeInternals])

  const changeDirection = useCallback((dir) => {
    setDirection(dir)
    relayout(dir)
  }, [relayout])

  const flash = useCallback((text, tone = 'ok') => {
    setStatus({ text, tone })
    setTimeout(() => setStatus(null), 5000)
  }, [])

  // "Whole board" captures everything including title and legend. "Current
  // view" captures exactly what is on screen, which is the sane answer when a
  // board is too wide to be legible in a single image.
  const exportTarget = useCallback(() => {
    if (area === 'view') {
      const el = paneRef.current
      const r = el?.getBoundingClientRect()
      if (r) {
        const b = viewportBounds(getViewport(), r.width, r.height)
        if (b) return { bounds: b, pad: 0 }
      }
    }
    return { bounds: frameRef.current?.outer, pad: undefined }
  }, [area, getViewport])

  const handleDownload = useCallback(async () => {
    setBusy('download')
    setSelection(null)
    try {
      const { bounds, pad } = exportTarget()
      const r = await exportPng(bounds, {
        scale,
        transparent,
        pad,
        filename: parsedRef.current?.meta?.title || currentFileName(currentFile),
      })
      flash(
        `Saved ${r.outWidth} × ${r.outHeight} px` +
          (r.clamped ? `. Too large for ${scale}×, rendered at ${r.effective.toFixed(2)}×. Try Current view.` : ''),
        r.clamped ? 'warn' : 'ok'
      )
    } catch (e) {
      flash(e.message, 'bad')
    } finally {
      setBusy(null)
    }
  }, [scale, transparent, currentFile, flash, exportTarget])

  const handleCopy = useCallback(async () => {
    setBusy('copy')
    setSelection(null)
    try {
      const { bounds, pad } = exportTarget()
      const r = await copyPng(bounds, { scale, transparent, pad })
      flash(
        `Copied ${r.outWidth} × ${r.outHeight} px` +
          (r.clamped ? `. Capped at ${r.effective.toFixed(2)}×.` : '. Paste into your deck.'),
        r.clamped ? 'warn' : 'ok'
      )
    } catch (e) {
      flash(e.message, 'bad')
    } finally {
      setBusy(null)
    }
  }, [scale, transparent, flash, exportTarget])

  const handleSaveJson = useCallback(() => {
    const doc = serializeWorkflow(sourceDoc, nodes)
    downloadJson(doc, parsedRef.current?.meta?.title || currentFileName(currentFile))
    flash('JSON saved with current node positions')
  }, [sourceDoc, nodes, currentFile, flash])

  const pickFile = useCallback((path) => {
    const f = FILE_LIST.find((x) => x.path === path)
    if (!f) return
    setCurrentFile(path)
    setSourceDoc(f.doc)
    setJsonText(JSON.stringify(f.doc, null, 2))
    persist(f.doc, path)
  }, [])

  const loadFile = useCallback(async (file) => {
    try {
      const text = await file.text()
      const doc = JSON.parse(text)
      setSourceDoc(doc)
      setJsonText(JSON.stringify(doc, null, 2))
      setCurrentFile(file.name)
      persist(doc, file.name)
      flash(`Loaded ${file.name}`)
    } catch (e) {
      flash(`Could not read ${file.name}: ${e.message}`, 'bad')
    }
  }, [flash])

  const applyJson = useCallback((doc, text) => {
    setSourceDoc(doc)
    setJsonText(text)
    persist(doc, currentFile)
    flash('Applied')
  }, [flash, currentFile])

  const onDrop = useCallback((e) => {
    e.preventDefault()
    const f = e.dataTransfer?.files?.[0]
    if (f && /\.json$/i.test(f.name)) loadFile(f)
  }, [loadFile])

  // ---- shortcuts -----------------------------------------------------------
  useEffect(() => {
    function onKey(e) {
      if (e.target.matches?.('input, textarea, select')) return
      if (e.key === 'f' || e.key === 'F') fit()
      if (e.key === 'l' || e.key === 'L') relayout()
      if (e.key === 'Escape') setSelection(null)
      if ((e.metaKey || e.ctrlKey) && (e.key === 'e' || e.key === 'E')) { e.preventDefault(); handleDownload() }
      if ((e.metaKey || e.ctrlKey) && e.shiftKey && (e.key === 'c' || e.key === 'C')) { e.preventDefault(); handleCopy() }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [fit, relayout, handleDownload, handleCopy])

  // Show the user what they are about to get, before they click. In view mode
  // this tracks the pan and zoom live.
  const [vp, setVp] = useState(null)
  const preview = useMemo(() => {
    try {
      const { bounds, pad } = exportTarget()
      const p = planExport(bounds, scale, pad)
      return { text: `${p.outWidth} × ${p.outHeight}`, clamped: p.clamped }
    } catch {
      return null
    }
    // vp is a deliberate dependency: it is what makes the readout live.
  }, [frame, scale, area, vp, exportTarget])

  return (
    <div className="wf-app" onDrop={onDrop} onDragOver={(e) => e.preventDefault()}>
      <Toolbar
        files={FILE_LIST}
        currentFile={currentFile}
        onPickFile={pickFile}
        onUploadFile={loadFile}
        direction={direction}
        onDirection={changeDirection}
        scale={scale}
        onScale={setScale}
        area={area}
        onArea={setArea}
        transparent={transparent}
        onTransparent={setTransparent}
        showLanes={showLanes}
        onShowLanes={setShowLanes}
        showLegend={showLegend}
        onShowLegend={setShowLegend}
        trackpad={trackpad}
        onTrackpad={setTrackpad}
        onRelayout={() => relayout()}
        onFit={() => fit()}
        onDownload={handleDownload}
        onCopy={handleCopy}
        onSaveJson={handleSaveJson}
        onToggleJson={() => setJsonOpen((v) => !v)}
        busy={busy}
        status={status}
        problemCount={problems.length}
        preview={preview}
      />

      <div
        className={`wf-stage${selection ? ' has-panel' : ''}${jsonOpen ? ' has-drawer' : ''}`}
        ref={paneRef}
      >
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onNodeDragStop={refreshLanes}
          onMove={area === 'view' ? (_, next) => setVp(next) : undefined}
          nodeTypes={nodeTypes}
          onNodeClick={(_, node) => setSelection({ type: 'node', data: node })}
          onEdgeClick={(_, edge) => setSelection({ type: 'edge', data: edge })}
          onPaneClick={() => setSelection(null)}
          /* An unbounded board: no translateExtent, no nodeExtent, and a very
             wide zoom range so a 200-node diagram still fits on screen. */
          minZoom={0.03}
          maxZoom={5}
          zoomOnScroll={!trackpad}
          panOnScroll={trackpad}
          zoomOnPinch
          panOnDrag
          selectionOnDrag={false}
          zoomOnDoubleClick={false}
          nodesConnectable={false}
          elevateEdgesOnSelect
          defaultEdgeOptions={{ interactionWidth: 18 }}
        >
          <Background variant={BackgroundVariant.Dots} gap={22} size={1.2} color="#dbe2ea" />
          <Controls showInteractive={false} position="bottom-left" />
          <MiniMap
            pannable
            zoomable
            position="bottom-right"
            nodeStrokeWidth={2}
            nodeColor={(n) => kindStyle(n.data?.kind).accent}
            maskColor="rgba(241, 245, 249, 0.72)"
          />

          <LaneLayer lanes={lanes} visible={showLanes} />
          <DiagramTitle meta={parsed.meta} frame={frame} />
          <Legend nodes={nodes} edges={edges} frame={frame} />
        </ReactFlow>

        <DetailPanel selection={selection} onClose={() => setSelection(null)} />

        <JsonDrawer
          open={jsonOpen}
          text={jsonText}
          problems={problems}
          onApply={applyJson}
          onClose={() => setJsonOpen(false)}
        />
      </div>
    </div>
  )
}

function currentFileName(path) {
  return String(path).split('/').pop().replace(/\.json$/, '')
}

function persist(doc, file) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ __v: 2, file: file || null, doc }))
  } catch {
    /* private browsing, quota, or a very large diagram; not worth failing over */
  }
}

function restore() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw)
    if (parsed && parsed.__v === 2 && parsed.doc) return parsed
    // Older builds stored the bare document with no file reference.
    if (parsed && Array.isArray(parsed.nodes)) return { file: null, doc: parsed }
    return null
  } catch {
    return null
  }
}
