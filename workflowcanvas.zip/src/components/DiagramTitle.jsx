import { memo } from 'react'
import { ViewportPortal } from '@xyflow/react'

/**
 * The title block lives inside the viewport rather than in fixed page chrome,
 * so it lands in the exported image instead of being filtered out as UI.
 * Its rectangle comes from computeFrame(), which is the same rectangle the
 * exporter captures — the two cannot drift apart.
 */
function DiagramTitle({ meta, frame }) {
  if (!meta || !frame) return null
  const { title, footnote } = frame

  return (
    <ViewportPortal>
      {title && (
        <div
          className="wf-title"
          style={{
            position: 'absolute',
            transform: `translate(${title.x}px, ${title.y}px)`,
            width: title.width,
          }}
        >
          {meta.title && <div className="wf-title__main">{meta.title}</div>}
          {meta.subtitle && <div className="wf-title__sub">{meta.subtitle}</div>}
          {meta.owner && <div className="wf-title__owner">Owner: {meta.owner}</div>}
        </div>
      )}

      {footnote && meta.footnote && (
        <div
          className="wf-footnote"
          style={{
            position: 'absolute',
            transform: `translate(${footnote.x}px, ${footnote.y}px)`,
            width: footnote.width,
          }}
        >
          {meta.footnote}
        </div>
      )}
    </ViewportPortal>
  )
}

export default memo(DiagramTitle)
