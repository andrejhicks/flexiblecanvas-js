import { memo } from 'react'
import { ViewportPortal } from '@xyflow/react'
import { groupColor } from '../lib/theme.js'

/**
 * Swimlane bands, drawn inside the React Flow viewport so they pan and zoom
 * with the graph and get captured by the image export. Rendered behind the
 * nodes and completely non-interactive.
 */
function LaneLayer({ lanes, visible }) {
  if (!visible || !lanes || lanes.length === 0) return null

  return (
    <ViewportPortal>
      <div className="wf-lanes" style={{ position: 'absolute', left: 0, top: 0, zIndex: -1 }}>
        {lanes.map((lane) => {
          const c = groupColor(lane.color)
          return (
            <div
              key={lane.id}
              className="wf-lane"
              style={{
                position: 'absolute',
                transform: `translate(${lane.x}px, ${lane.y}px)`,
                width: lane.width,
                height: lane.height,
                '--lane': c,
              }}
            >
              <div className="wf-lane__label">
                <span className="wf-lane__dot" />
                {lane.label}
                <span className="wf-lane__count">{lane.count}</span>
              </div>
            </div>
          )
        })}
      </div>
    </ViewportPortal>
  )
}

export default memo(LaneLayer)
