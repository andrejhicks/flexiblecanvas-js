import { memo } from 'react'
import { ViewportPortal } from '@xyflow/react'
import { KINDS, EDGE_KINDS } from '../lib/theme.js'

const EDGE_LABELS = {
  default: 'Sequence',
  conditional: 'Conditional',
  async: 'Async',
  error: 'Failure path',
  data: 'Data flow',
  feedback: 'Loop back',
}

/**
 * Only the kinds actually used in this diagram are listed. A legend full of
 * shapes that do not appear on the board is noise.
 */
function Legend({ nodes, edges, frame }) {
  if (!frame?.legend) return null

  const usedKinds = [...new Set(nodes.map((n) => n.data?.kind).filter(Boolean))]
  const usedEdges = [...new Set(edges.map((e) => e.data?.kind || 'default'))]
  if (usedKinds.length === 0) return null

  return (
    <ViewportPortal>
      <div
        className="wf-legend"
        style={{
          position: 'absolute',
          transform: `translate(${frame.legend.x}px, ${frame.legend.y}px)`,
          width: frame.legend.width,
        }}
      >
        <div className="wf-legend__heading">Key</div>

        <div className="wf-legend__group">
          {usedKinds.map((k) => {
            const s = KINDS[k]
            if (!s) return null
            return (
              <div key={k} className="wf-legend__row">
                <span className="wf-legend__swatch" style={{ background: s.soft, borderColor: s.accent, color: s.accent }}>
                  {s.icon}
                </span>
                <span>{s.label}</span>
              </div>
            )
          })}
        </div>

        {usedEdges.length > 1 && (
          <>
            <div className="wf-legend__divider" />
            <div className="wf-legend__group">
              {usedEdges.map((k) => {
                const s = EDGE_KINDS[k] || EDGE_KINDS.default
                return (
                  <div key={k} className="wf-legend__row">
                    <svg width="30" height="10" className="wf-legend__line" aria-hidden="true">
                      <line
                        x1="1" y1="5" x2="29" y2="5"
                        stroke={s.stroke}
                        strokeWidth={s.width}
                        strokeDasharray={s.dash || undefined}
                      />
                    </svg>
                    <span>{EDGE_LABELS[k] || k}</span>
                  </div>
                )
              })}
            </div>
          </>
        )}
      </div>
    </ViewportPortal>
  )
}

export default memo(Legend)
