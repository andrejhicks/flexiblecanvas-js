import { kindStyle, METRIC_TONES, edgeStyle } from '../lib/theme.js'

export default function DetailPanel({ selection, onClose }) {
  if (!selection) return null

  if (selection.type === 'edge') {
    const e = selection.data
    const s = edgeStyle(e.data?.kind)
    return (
      <aside className="wf-panel no-export">
        <header className="wf-panel__head" style={{ '--accent': s.stroke }}>
          <div className="wf-panel__eyebrow">Connection</div>
          <h2 className="wf-panel__title">{e.label || 'Untitled connection'}</h2>
          <button className="wf-panel__close" onClick={onClose} aria-label="Close">×</button>
        </header>
        <div className="wf-panel__body">
          <Field label="From">{e.source}</Field>
          <Field label="To">{e.target}</Field>
          <Field label="Type">{e.data?.kind || 'default'}</Field>
          {e.data?.note && <Field label="Note">{e.data.note}</Field>}
        </div>
      </aside>
    )
  }

  const n = selection.data
  const d = n.data || {}
  const k = kindStyle(d.kind)

  return (
    <aside className="wf-panel no-export">
      <header className="wf-panel__head" style={{ '--accent': k.accent }}>
        <div className="wf-panel__eyebrow">
          <span aria-hidden="true">{k.icon}</span> {k.label}
          {d.status && d.status !== 'current' && <span className="wf-panel__pill">{d.status}</span>}
        </div>
        <h2 className="wf-panel__title">{d.label}</h2>
        {d.subtitle && <p className="wf-panel__sub">{d.subtitle}</p>}
        <button className="wf-panel__close" onClick={onClose} aria-label="Close">×</button>
      </header>

      <div className="wf-panel__body">
        {d.emotion && (() => {
          const t = METRIC_TONES[d.emotion.tone] || METRIC_TONES.neutral
          return (
            <div className="wf-panel__emotion" style={{ background: t.bg, color: t.fg }}>
              Feeling: {d.emotion.label}
            </div>
          )
        })()}

        {d.quote && <blockquote className="wf-panel__quote">&ldquo;{d.quote}&rdquo;</blockquote>}

        {d.description && <p className="wf-panel__prose">{d.description}</p>}

        {(d.owner || d.system || d.duration || d.group) && (
          <div className="wf-panel__grid">
            {d.owner && <Field label="Owner">{d.owner}</Field>}
            {d.system && <Field label="System">{d.system}</Field>}
            {d.duration && <Field label="Duration">{d.duration}</Field>}
            {d.group && <Field label="Lane">{d.group}</Field>}
          </div>
        )}

        {(d.details || []).length > 0 && (
          <section>
            <h3 className="wf-panel__h3">Details</h3>
            <ul className="wf-panel__list">
              {d.details.map((x, i) => <li key={i}>{x}</li>)}
            </ul>
          </section>
        )}

        {(d.metrics || []).length > 0 && (
          <section>
            <h3 className="wf-panel__h3">Metrics</h3>
            <div className="wf-panel__metrics">
              {d.metrics.map((m, i) => {
                const tone = METRIC_TONES[m.tone] || METRIC_TONES.neutral
                return (
                  <div key={i} className="wf-panel__metric" style={{ background: tone.bg, color: tone.fg }}>
                    <div className="wf-panel__metricval">{m.value}</div>
                    <div className="wf-panel__metriclabel">{m.label}</div>
                  </div>
                )
              })}
            </div>
          </section>
        )}

        {(d.tags || []).length > 0 && (
          <div className="wf-panel__tags">
            {d.tags.map((t, i) => <span key={i} className="wf-node__tag">{t}</span>)}
          </div>
        )}

        {d.link && (
          <a className="wf-panel__link" href={d.link} target="_blank" rel="noreferrer">
            Open reference ↗
          </a>
        )}

        <Field label="Node id"><code>{n.id}</code></Field>
      </div>
    </aside>
  )
}

function Field({ label, children }) {
  return (
    <div className="wf-field">
      <div className="wf-field__label">{label}</div>
      <div className="wf-field__value">{children}</div>
    </div>
  )
}
