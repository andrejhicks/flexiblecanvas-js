import { useEffect, useState } from 'react'

export default function JsonDrawer({ open, text, problems, onApply, onClose }) {
  const [draft, setDraft] = useState(text)
  const [error, setError] = useState('')

  useEffect(() => {
    setDraft(text)
    setError('')
  }, [text, open])

  if (!open) return null

  function apply() {
    try {
      const parsed = JSON.parse(draft)
      setError('')
      onApply(parsed, draft)
    } catch (e) {
      setError(friendlyJsonError(e, draft))
    }
  }

  return (
    <aside className="wf-drawer no-export">
      <header className="wf-drawer__head">
        <h2>Diagram JSON</h2>
        <div className="wf-drawer__actions">
          <button className="wf-btn wf-btn--primary" onClick={apply}>Apply</button>
          <button className="wf-btn" onClick={onClose}>Close</button>
        </div>
      </header>

      {error && <div className="wf-drawer__error">{error}</div>}

      {problems.length > 0 && (
        <div className="wf-drawer__warn">
          <strong>{problems.length} thing{problems.length === 1 ? '' : 's'} to look at</strong>
          <ul>
            {problems.slice(0, 12).map((p, i) => <li key={i}>{p}</li>)}
            {problems.length > 12 && <li>…and {problems.length - 12} more</li>}
          </ul>
        </div>
      )}

      <textarea
        className="wf-drawer__editor"
        value={draft}
        spellCheck={false}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); apply() }
        }}
      />

      <footer className="wf-drawer__foot">
        Cmd/Ctrl + Enter applies. Edits live here only. Use Save JSON to keep them.
      </footer>
    </aside>
  )
}

function friendlyJsonError(e, text) {
  const msg = String(e.message || e)
  const m = msg.match(/position (\d+)/)
  if (!m) return msg
  const pos = Number(m[1])
  const line = text.slice(0, pos).split('\n').length
  const col = pos - text.lastIndexOf('\n', pos - 1)
  return `${msg.split(' in JSON')[0]} at line ${line}, column ${col}. A trailing comma or a missing quote is the usual cause.`
}
